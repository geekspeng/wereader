/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/content/modules/content-hook.ts":
/*!*********************************************!*\
  !*** ./src/content/modules/content-hook.ts ***!
  \*********************************************/
/***/ (function() {



var __awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
const DATA_ID = '__weread_chapter_data';
const MARK = '/web/book/chapter/e_';
function decodeChunk(body) {
  try {
    const bin = atob(body.slice(33));
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder('utf-8').decode(bytes);
  } catch (e) {
    return '';
  }
}
function readStore() {
  const el = document.getElementById(DATA_ID);
  if (!el || !el.textContent) return {
    current: '',
    chapters: {}
  };
  try {
    return JSON.parse(el.textContent);
  } catch (e) {
    return {
      current: '',
      chapters: {}
    };
  }
}
function writeStore(store) {
  let el = document.getElementById(DATA_ID);
  if (!el) {
    el = document.createElement('script');
    el.id = DATA_ID;
    el.type = 'application/json';
    const root = document.head || document.documentElement;
    root.appendChild(el);
  }
  el.textContent = JSON.stringify(store);
}
function chapterIndexFromUrl(url) {
  const at = url.indexOf(MARK);
  if (at === -1) return -1;
  const tail = url.slice(at + MARK.length);
  let n = '';
  for (let i = 0; i < tail.length; i += 1) {
    const c = tail.charCodeAt(i);
    if (c >= 48 && c <= 57) n += tail[i];else break;
  }
  return n ? parseInt(n, 10) : -1;
}
function chapterIdFromBody(body) {
  if (typeof body !== 'string' || !body) return '';
  try {
    const parsed = JSON.parse(body);
    return parsed.c || '';
  } catch (e) {
    return '';
  }
}
function processChunk(url, reqBody, responseText) {
  const idx = chapterIndexFromUrl(url);
  if (idx < 0) return;
  const cid = chapterIdFromBody(reqBody);
  const h = decodeChunk(responseText);
  if (!h || h.indexOf('<') === -1) return;
  const store = readStore();
  if (!store.chapters[cid]) store.chapters[cid] = {};
  store.chapters[cid][idx] = h;
  store.current = cid;
  writeStore(store);
}
function requestUrl(input) {
  if (typeof input === 'string') return input;
  if (input instanceof URL) return input.href;
  if (input) return input.url;
  return '';
}
const origFetch = window.fetch;
window.fetch = function hookFetch(input, init) {
  return __awaiter(this, void 0, void 0, function* () {
    const res = yield origFetch.call(this, input, init);
    try {
      const url = requestUrl(input);
      if (url.indexOf(MARK) !== -1) {
        res.clone().text().then(function onText(t) {
          processChunk(url, init && init.body, t);
        }).catch(function onErr() {});
      }
    } catch (e) {}
    return res;
  });
};
const origOpen = XMLHttpRequest.prototype.open;
XMLHttpRequest.prototype.open = function hookOpen(...args) {
  const url = args[1];
  this.__chUrl = typeof url === 'string' ? url : String(url);
  return Reflect.apply(origOpen, this, args);
};
const origSend = XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.send = function hookSend(...args) {
  const xhr = this;
  const body = args[0];
  if (xhr.__chUrl && xhr.__chUrl.indexOf(MARK) !== -1) {
    xhr.addEventListener('load', function onLoad() {
      try {
        processChunk(xhr.__chUrl || '', body, xhr.responseText);
      } catch (e) {}
    });
  }
  return Reflect.apply(origSend, this, args);
};

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/content/modules/content-hook.ts"]();
/******/ 	
/******/ })()
;
//# sourceMappingURL=content-hook.js.map